%% 首先输入每个评价指标数据，每行是一年的数据，每列是一个省份或指标
data = [
16409541.2	558641.4	1953357	115735.6	-335638.6	1163124.7	359223.1	-70812.3	517930.6	7346942	13632202.3	2262288.8	1274918.2	1653371.1	4514050.6	916004.1	-1941262.6	1196807.9	12648049.8	1043866.4	11949.7	2703004.9	943708	496728.9	936657.4	59665.5	1419459.8	238950.6	5869200	255169.9	-63998
14845840.3	1004876.2	1803196.2	2312592	5723554.8	-258383.6	6129162.1	-151323.5	4128466	9903107.8	1153418.2	3206873.1	2709221.4	777475.7	5674997.8	2797022.2	3795583.3	581438.5	9496739.4	997992.4	646889.5	1372068.7	7296623.7	355146.2	106337.2	148947.3	3683003.4	713823.7	352798.1	236464.1	5017007.5
-3819635.7	-494445.8	-4914152.8	-1027002.5	2950080.1	668613.8	-387182.9	710977.1	-506661.7	3498447.1	4071218.4	-387063.6	1047037.8	2318892.8	246004.7	722618.3	1405915.9	1471465.2	-5699467.5	-1500087.2	-355440	-471346.7	2905942.1	388341.5	141591.2	-202752.7	2447276.6	-375118.1	2741126.7	374952.8	4705221.7
];
% 获取数据的维度
[n, m] = size(data);
% 数据归一化到 [-1, 1]
data_normalized = zeros(n, m);
for j = 1:m
    col_min = min(data(:, j));
    col_max = max(data(:, j));
    data_normalized(:, j) = 2 * (data(:, j) - col_min) / (col_max - col_min) - 1;
end
total_u = zeros(1, m);
% 遍历每列（即每个省份或指标）
for j = 1:m
    v_ijk = data_normalized(:, j);
    total_gain = 0;
    for k = 1:(n-1)
        v_start = v_ijk(k);
        v_end = v_ijk(k + 1);
        t_k = k - 1;
        t_k_plus_1 = k;
        integrand = @(t) v_start + (t - t_k) * (v_end - v_start) / (t_k_plus_1 - t_k);
        total_gain = total_gain + integral(integrand, t_k, t_k_plus_1);
    end
    total_u(j) = total_gain;
end
% 输出结果
disp('Total gain rate for each province or indicator over three years (normalized):');
disp(total_u);
% 导出结果
writematrix(total_u, 'result_export.xlsx');

%将结果存储在xls中，命名为moni，接下来进行指标分层及递归激励赋权计算
disp(moni); 
moni.Properties.RowNames = string(moni{:, 1});  
moni(:, 1) = [];  
moni_transposed = rows2vars(moni);
%计算指标分层
indicators = moni{:, 1};   
data = moni{:, 2:end};    
[num_indicators, num_provinces] = size(data); 
classification = strings(num_indicators, 1);
threshold = 0.8;  % 划分标准 80%
for i = 1:num_indicators
    positive_ratio = sum(data(i, :) >= 0) / num_provinces;
    if positive_ratio > threshold
        classification(i) = "良性指标";
    elseif positive_ratio == threshold
        classification(i) = "常态指标";
    else
        classification(i) = "风险指标";
    end
end
moni.Classification = classification;
disp(moni);
writetable(moni, '分类结果.xlsx');
% 计算 a(j) 和 b(j)
data = moni_transposed; 
num_provinces = height(data); 
threshold_value = 0; 
good_ratios = zeros(1, width(data) - 1); % 每个指标的良性比例
risk_ratios = zeros(1, width(data) - 1); % 每个指标的风险比例
% 计算良性比例和风险比例
for i = 2:width(data) 
    current_indicator = data{:, i}; 
    num_good = sum(current_indicator >= threshold_value); 
    good_ratios(i - 1) = num_good / num_provinces; 
    risk_ratios(i - 1) = 1 - good_ratios(i - 1); 
end
% 根据动态分类计算全局比例和个体激励量
a = zeros(1, width(data) - 1); 
b = zeros(1, width(data) - 1); 
for i = 1:(width(data) - 1)
    if good_ratios(i) >= 0.8 
        a(i) = good_ratios(i) / sum(good_ratios); 
        b(i) = 0; 
    else 
        a(i) = 0; 
        b(i) = risk_ratios(i) / sum(risk_ratios); 
    end
end
% 输出结果
results_table = table(data.Properties.VariableNames(2:end)', a', b', ...
    'VariableNames', {'指标名称', '正向激励量_a(j)', '负向激励量_b(j)'});
disp(results_table);
% 保存结果为 Excel 文件
writetable(results_table, '激励量计算结果.xlsx', 'WriteVariableNames', true);
%划分阶段
data = moni_transposed; 
num_provinces = height(data); 
threshold_value = 0; 
good_ratio_threshold = 0.8; 
% 阶段划分
stage1_indices = 2:12;  
stage2_indices = 13:14;  
stage3_indices = 15:19; 
stage_classification = table();
% 遍历阶段
for stage = 1:3
    switch stage
        case 1
            stage_indices = stage1_indices;
            stage_name = '阶段一 (k1)';
        case 2
            stage_indices = stage2_indices;
            stage_name = '阶段二 (k2)';
        case 3
            stage_indices = stage3_indices;
            stage_name = '阶段三 (k3)';
    end
    for i = stage_indices
        current_indicator = data{:, i}; 
        num_good = sum(current_indicator > threshold_value); 
        ratio = num_good / num_provinces; 
        % 分类
        if ratio > good_ratio_threshold
            stage_classification.(data.Properties.VariableNames{i}) = ...
                {stage_name, '良性指标'};
        else
            stage_classification.(data.Properties.VariableNames{i}) = ...
                {stage_name, '风险指标'};
        end
    end
end
% 结果
stage_classification_transposed = stack(stage_classification, ...
    1:width(stage_classification), ...
    'NewDataVariableName', '分类结果', ...
    'IndexVariableName', '指标名称');
disp(stage_classification_transposed);
data = moni_transposed; 
num_provinces = height(data); 
threshold_value = 0; 
good_ratios = zeros(1, width(data) - 1); % 每个指标的良性比例
risk_ratios = zeros(1, width(data) - 1); % 每个指标的风险比例
% 计算良性比例和风险比例
for i = 2:width(data)
    current_indicator = data{:, i}; 
    if iscell(current_indicator) 
        current_indicator = str2double(current_indicator); 
    elseif ~isnumeric(current_indicator) 
        current_indicator = str2double(string(current_indicator)); 
    end
    if any(isnan(current_indicator))
        warning(['指标 ', data.Properties.VariableNames{i}, ' 包含非数字值，已忽略。']);
        continue;
    end
    % 计算良性比例和风险比例
    num_good = sum(current_indicator >= threshold_value); 
    good_ratios(i - 1) = num_good / num_provinces; % 计算良性比例
    risk_ratios(i - 1) = 1 - good_ratios(i - 1); % 计算风险比例
end
% 初始化正向激励量和负向激励量
a = zeros(1, width(data) - 1); % 正向激励量
b = zeros(1, width(data) - 1); % 负向激励量
% 动态分类并计算激励量
for i = 2:width(data)
    if good_ratios(i - 1) >= 0.8 % 如果良性比例大于等于0.6，则为良性指标
        a(i - 1) = good_ratios(i - 1) / sum(good_ratios); 
        b(i - 1) = 0; % 
    elseif good_ratios(i - 1) < 0.8 % 
        a(i - 1) = 0; % 
        b(i - 1) = risk_ratios(i - 1) / sum(risk_ratios);
    end
end
% 输出每个指标的激励量
disp('每个指标的良性激励量a(j)和风险激励量b(j):');
for i = 1:width(data) - 1
    if a(i) > 0
        disp([data.Properties.VariableNames{i + 1}, ' -> 良性激励量 a(j) = ', num2str(a(i))]);
    elseif b(i) > 0
        disp([data.Properties.VariableNames{i + 1}, ' -> 风险激励量 b(j) = ', num2str(b(i))]);
    end
end
% 计算阶段总激励量
stage_total_a = zeros(1, 3);  % 每个阶段的总良性激励量
stage_total_b = zeros(1, 3);  % 每个阶段的总风险激励量

% 为每个阶段计算激励量
stage_indices = {1:11, 12:13, 14:18};  % 阶段的指标范围（根据实际情况修改）
for stage = 1:3
    % 获取当前阶段的所有指标
    current_stage_indices = stage_indices{stage};
    
    % 获取该阶段的所有指标的良性比例
    stage_good_ratios = good_ratios(current_stage_indices);
    
    % 获取该阶段的所有指标的风险比例
    stage_risk_ratios = risk_ratios(current_stage_indices);
    
    % 计算当前阶段的总激励量
    sum_stage_good = sum(stage_good_ratios);
    sum_stage_risk = sum(stage_risk_ratios);
    
    % 为每个指标计算激励量
    for i = current_stage_indices
        if good_ratios(i) >= 0.8 % 良性指标
            a(i) = good_ratios(i) / sum_stage_good;  % 计算正向激励量
        elseif good_ratios(i) < 0.8 % 风险指标
            b(i) = risk_ratios(i) / sum_stage_risk;  % 计算负向激励量
        end
    end
    
    % 汇总当前阶段的总良性激励量和风险激励量
    stage_total_a(stage) = sum(a(current_stage_indices));
    stage_total_b(stage) = sum(b(current_stage_indices));
end

% 输出每个阶段的总激励量
disp('每个阶段的总激励量:');
for stage = 1:3
    disp(['阶段 ', num2str(stage), ' -> 总良性激励量: ', num2str(stage_total_a(stage)), ...
          ', 总风险激励量: ', num2str(stage_total_b(stage))]);
end

%第一阶段的激励系数
% 阶段 1 的良性激励量和风险激励量
a1 = stage_total_a(1); % 阶段 1 的总良性激励量
b1 = stage_total_b(1); % 阶段 1 的总风险激励量

% 计算初始正向和负向激励系数
Z(1) = b1 / (a1 + b1); % 正向激励系数
F(1) = a1 / (a1 + b1); % 负向激励系数

% 输出初始值
disp(['阶段 1 的初始正向激励系数 Z(1): ', num2str(Z(1))]);
disp(['阶段 1 的初始负向激励系数 F(1): ', num2str(F(1))]);

%第二阶段第三阶段的激励系数
% 初始化权重系数 epsilon
epsilon = 0.3;

% 计算阶段 1 的初始值
a1 = stage_total_a(1); % 阶段 1 的总良性激励量
b1 = stage_total_b(1); % 阶段 1 的总风险激励量
Z(1) = b1 / (a1 + b1); % 正向激励系数
F(1) = 1 - Z(1);       % 负向激励系数

% 递归计算阶段 2 和阶段 3 的激励系数
for k = 2:3
    % 当前阶段的总激励量
    total_a_integral = stage_total_a(k); % 当前阶段良性激励量
    total_b_integral = stage_total_b(k); % 当前阶段风险激励量
    
    % 计算 Z(k) 和 F(k)，确保满足 Z(k) + F(k) = 1
    Z(k) = epsilon * Z(k-1) + (1 - epsilon) * (total_b_integral / (total_a_integral + total_b_integral));
    F(k) = 1 - Z(k); % 直接计算 F(k) 确保约束
end

% 输出每阶段的激励系数
disp('每个阶段的正向激励系数 Z(k) 和负向激励系数 F(k):');
for k = 1:3
    disp(['阶段 ', num2str(k), ' -> Z(k): ', num2str(Z(k)), ', F(k): ', num2str(F(k))]);
end

% 验证激励量守恒
% 各阶段的良性激励量和风险激励量
a = stage_total_a; % 总良性激励量
b = stage_total_b; % 总风险激励量

% 初始化验证结果
for k = 1:3
    % 计算当前阶段的正向和负向激励系数
    Z_k = b(k) / (a(k) + b(k)); % 正向激励系数
    F_k = 1 - Z_k;             % 负向激励系数

    % 计算左右乘积
    left_side = Z_k * a(k); % Z(k) * a(k)
    right_side = F_k * b(k); % F(k) * b(k)

    % 输出结果
    disp(['阶段 ', num2str(k), ' 的验证结果:']);
    disp(['  左边 (Z(k) * a(k)): ', num2str(left_side)]);
    disp(['  右边 (F(k) * b(k)): ', num2str(right_side)]);

    % 判断守恒性
    if abs(left_side - right_side) < 1e-6
        disp(['  阶段 ', num2str(k), ' 的激励量守恒']);
    else
        disp(['  阶段 ', num2str(k), ' 的激励量未守恒，请检查数据或公式']);
    end
end
% 初始指标权重（critic权重法）
initial_weights = [0.0418, 0.12278, 0.05143, 0.08365, 0.08198, 0.06815, 0.04507, ...
                  0.09735, 0.06373, 0.01591, 0.01507, 0.02479, 0.02351, 0.06869, ...
                  0.05051, 0.09635, 0.03476, 0.01448]; % 18个初始权重
scaling_factor = 0.3; % 调整权重的比例因子
num_indicators = numel(initial_weights);
final_weights = initial_weights;
% 显示初始权重
disp('初始权重:');
disp(initial_weights);
% 定义阶段范围和激励系数
stage_ranges = {1:11, 12:13, 14:18}; % 定义阶段的指标范围
Z = [0.51258, 0.15377,0.30444]; % 正向激励系数
F = [0.48742, 0.84623, 0.69556]; % 负向激励系数
scaling_factor = 0.3; % 缩放因子
a = [0.0662	0.0574	0.0684	0.0596	0	0	0.0574	0	0	0.0684	0.0684	0.0662	0.064	0.0552	0.0596	0	0.064	0.0684]; % 良性激励量
b = [0	0	0	0	0.1238	0.0667	0	0.2381	0.1714	0	0	0	0	0	0	0.1143	0	0]; % 风险激励量
stage_ranges = {1:11, 12:13, 14:18}; % 每个阶段对应的列范围
for j = 1:18 
    for k = 1:length(stage_ranges)
        if ismember(j, stage_ranges{k})
            Zk = Z(k); 
            Fk = F(k);
            disp(['指标 ' num2str(j) ' 所属阶段: ' num2str(k)]);
            disp(['  正向激励系数 Z(k): ' num2str(Zk)]);
            disp(['  负向激励系数 F(k): ' num2str(Fk)]);
            break; 
        end
    end
end
for k = 1:length(stage_ranges)
    stage_indices = stage_ranges{k};
    Zk = Z(k); 
    Fk = F(k); 
    for j = stage_indices
        weight_adjustment = scaling_factor * (Zk * a(i) - Fk * b(i));
        final_weights(j) = final_weights(j) + weight_adjustment;
        final_weights(j) = max(0, final_weights(j)); % 保证非负
    end
    stage_sum = sum(final_weights(stage_indices));
    if stage_sum == 0
        error(['阶段 ' num2str(k) ' 的权重总和为0，无法归一化！']);
    end
    final_weights(stage_indices) = final_weights(stage_indices) / stage_sum;
    disp(['阶段 ' num2str(k) ' 后的权重:']);
    disp(final_weights);
end
total_sum = sum(final_weights);
if total_sum == 0
    error('权重总和为0，无法归一化！');
end
final_weights = final_weights / total_sum;
% 显示最终权重
disp('最终权重:');
disp(final_weights);
%阶段权重的递归
num_stages = 3; % 总阶段数
initial_stage_weight = 0.6869; % 初始阶段权重（即第一阶段的初始权重）
epsilon = 0.3; % 调节参数
gamma = 0.2; % 衰减参数
T = 3; % 时间范围
stage_weights = zeros(1, num_stages);
stage_weights(1) = initial_stage_weight; % 第一阶段权重固定
for k = 2:num_stages
    ak = stage_total_a(k); 
    bk = stage_total_b(k); 
    Zk = Z(k); 
    Fk = F(k); 
    current_contribution = epsilon * T * (ak * Zk - bk * Fk);
    historical_contribution = 0;
    for j = 1:(k-1)
        aj = stage_total_a(j); 
        bj = stage_total_b(j); 
        Zj = Z(j); 
        Fj = F(j);
        historical_contribution = historical_contribution + ...
            exp(-gamma * (k - j - 1)) * T * (aj * Zj - bj * Fj);
    end
    stage_weights(k) = stage_weights(k-1) + current_contribution + historical_contribution;
end
other_weights_sum = sum(stage_weights(2:end));
stage_weights(2:end) = stage_weights(2:end) / other_weights_sum;
stage_weights(1) = initial_stage_weight;
stage_weights = stage_weights / sum(stage_weights);
% 显示阶段权重
disp('阶段权重:');
disp(stage_weights);
% 每个阶段的权重已经求出
stage_weights = [0.4072, 0.2406, 0.3522];  % 每个阶段的权重
stage_indices = {
    1:11,   
    12:13,  
    14:18  
};
% 显示初始权重
disp('初始权重:');
disp(final_weights);
% 对每个阶段进行权重调整
for k = 1:3
    current_stage_indices = stage_indices{k};  % 当前阶段的指标
    num_stage_indicators = length(current_stage_indices);  % 当前阶段的指标数量
    current_stage_weight = stage_weights(k);
    current_stage_weights = final_weights(current_stage_indices);
    normalized_weights = (current_stage_weights / sum(current_stage_weights)) * current_stage_weight;
    final_weights(current_stage_indices) = normalized_weights;
    disp(['阶段 ', num2str(k), ' 归一化后的权重:']);
    disp(final_weights(current_stage_indices));
end
% 显示最终的所有权重
disp('最终的所有指标的权重:');
disp(final_weights);
% 创建初始权重与最终权重的对比表格
indicator_names = arrayfun(@(x) ['指标' num2str(x)], 1:num_indicators, 'UniformOutput', false)';
weight_comparison_table = table(indicator_names, initial_weights', final_weights', ...
    'VariableNames', {'指标', '初始权重', '最终权重'});
% 显示权重对比表格
disp('初始权重与最终权重对比:');
disp(weight_comparison_table);
% 保存到文件
writetable(weight_comparison_table, 'weight_comparison.xlsx');
%求评价值（目前已经通过上述求出的最终权重,并根据该权重计算出评价值，保存在pingjiazhi.xlsx中）
stage_weights = [0.4072, 0.2406, 0.3522];  % 每个阶段的权重
data = pingjiazhi{:, 2:end};
stage1_indices = 2:7;    % 第一阶段列
stage2_indices = 8:10;   % 第二阶段列
stage3_indices = 10:13;  % 第三阶段列
num_provinces = size(data, 1); 
overall_evaluations = zeros(num_provinces, 1); 
delta_t = 1; 
% 循环计算每个省份的总评价值
for i = 1:num_provinces
    integral_stage1 = 0;
    integral_stage2 = 0;
    integral_stage3 = 0;
    for j = stage1_indices(1):stage1_indices(end)-1
        integral_stage1 = integral_stage1 + ...
            (data(i, j) + data(i, j + 1)) / 2 * delta_t;
    end
    for j = stage2_indices(1):stage2_indices(end)-1
        integral_stage2 = integral_stage2 + ...
            (data(i, j) + data(i, j + 1)) / 2 * delta_t;
    end
    for j = stage3_indices(1):stage3_indices(end)-1
        integral_stage3 = integral_stage3 + ...
            (data(i, j) + data(i, j + 1)) / 2 * delta_t;
    end
    overall_evaluations(i) = stage_weights(1) * integral_stage1 + ...
                             stage_weights(2) * integral_stage2 + ...
                             stage_weights(3) * integral_stage3;
end
pingjiazhi.DynamicEvaluationValue = overall_evaluations;  % 动态综合评价值
% 结果
disp(pingjiazhi);
writetable(pingjiazhi, '方法一评价值.xlsx');


%方法二：结合分层激励的递归激励赋权方法
% 目前已经将评价值根据公式（15）计算结果保存在表格 'pingjiazhichushi'中
years = pingjiazhichushi.Properties.VariableNames(2:end); 
provinces = pingjiazhichushi{:,1};  
evaluation_values = pingjiazhichushi{:,2:end};  
num_years = length(years);
num_provinces = length(provinces);
years = pingjiazhichushi.Properties.VariableNames(2:end); 
provinces = pingjiazhichushi{:, 1}; 
num_years = length(years);  
num_provinces = length(provinces);  
evaluation_values = pingjiazhichushi{:, 2:end};
reward_punishment = zeros(num_provinces, num_years);
for t = 1:num_years
    % 获取每年评价值的最大值、最小值和平均值
    max_value = max(evaluation_values(:, t));
    min_value = min(evaluation_values(:, t));
    avg_value = mean(evaluation_values(:, t));

    % 根据评价值分配奖励和惩罚
    % 1. 设置惩罚
    % 低于平均值的设置为惩罚，根据绝对值排序
    below_avg = evaluation_values(:, t) < avg_value;
    punishment_values = abs(evaluation_values(below_avg, t)); 
    [sorted_punishment, sorted_idx_punishment] = sort(punishment_values, 'descend');
    
    % 处理惩罚分配
    half_idx = floor(length(sorted_punishment) / 2);
    reward_punishment_idx = find(below_avg); 
    reward_punishment(reward_punishment_idx(sorted_idx_punishment(1:half_idx)), t) = -0.5;  % 一级惩罚
    reward_punishment(reward_punishment_idx(sorted_idx_punishment(half_idx+1:end)), t) = -0.2;  % 二级惩罚
    
    % 2. 设置奖励
    % 大于等于平均值的设置为奖励，根据绝对值排序
    above_avg = evaluation_values(:, t) >= avg_value;
    reward_values = abs(evaluation_values(above_avg, t));  
    [sorted_reward, sorted_idx_reward] = sort(reward_values, 'descend');
    
    % 处理奖励分配
    ten_percent_idx = floor(length(sorted_reward) * 0.1);
    fifty_percent_idx = floor(length(sorted_reward) * 0.5);
    reward_punishment_idx_reward = find(above_avg);  
    
    reward_punishment(reward_punishment_idx_reward(sorted_idx_reward(fifty_percent_idx+1:end)), t) = 0.3;  % 二级奖励
    reward_punishment(reward_punishment_idx_reward(sorted_idx_reward(1:ten_percent_idx)), t) = 0.5;  % 一级奖励
    reward_punishment(reward_punishment_idx_reward(sorted_idx_reward(ten_percent_idx+1:fifty_percent_idx)), t) = 0.1;  % 三级奖励
end
reward_punishment_table = array2table(reward_punishment, 'VariableNames', years, 'RowNames', provinces);
% 将结果保存为 .xlsx 文件
writetable(reward_punishment_table, 'youdaoxishu', 'WriteRowNames', true);
%计算评价值
years = pingjiazhi.Properties.VariableNames(2:end);  
provinces = pingjiazhi{:, 1}; 
evaluation_values = pingjiazhi{:, 2:end};  
rate_of_change = pingjiazhichushi{:, 2:end};  
coefficients = youdaoxishu{:, 2:end}; 
updated_values = evaluation_values; 
for t = 2:num_years
    for i = 1:num_provinces
        y_previous = evaluation_values(i, t-1);  
        delta_v_i = rate_of_change(i, t-1);  
        alpha_i = coefficients(i, t-1);  
        updated_values(i, t-1) = y_previous + alpha_i * delta_v_i;
    end
end
updated_values_table = array2table(updated_values, 'VariableNames', years, 'RowNames', provinces);
% 结果保存为 .xlsx 文件
writetable(updated_values_table, 'youdaohoui.xlsx', 'WriteRowNames', true);
%引入评价值计算公式
stage_weights = [0.4072, 0.2406, 0.3522];  % 每个阶段的权重
data = youdaohou{:, 2:end};
stage1_indices = 2:7;    % 第一阶段列
stage2_indices = 8:10;   % 第二阶段列
stage3_indices = 10:13;  % 第三阶段列
num_provinces = size(data, 1);  
overall_evaluations = zeros(num_provinces, 1);  
delta_t = 1; 
for i = 1:num_provinces
    integral_stage1 = 0;
    integral_stage2 = 0;
    integral_stage3 = 0;
    for j = stage1_indices(1):stage1_indices(end)-1
        integral_stage1 = integral_stage1 + ...
            (data(i, j) + data(i, j + 1)) / 2 * delta_t;
    end
    for j = stage2_indices(1):stage2_indices(end)-1
        integral_stage2 = integral_stage2 + ...
            (data(i, j) + data(i, j + 1)) / 2 * delta_t;
    end
    for j = stage3_indices(1):stage3_indices(end)-1
        integral_stage3 = integral_stage3 + ...
            (data(i, j) + data(i, j + 1)) / 2 * delta_t;
    end

    overall_evaluations(i) = stage_weights(1) * integral_stage1 + ...
                             stage_weights(2) * integral_stage2 + ...
                             stage_weights(3) * integral_stage3;
end

% 将结果存储到表中
pingjiazhi.DynamicEvaluationValue = overall_evaluations;  % 动态综合评价值

% 显示结果
disp(youdaohou);

% 如果需要保存到文件
writetable(pingjiazhi, '方法二评价值.xlsx');
